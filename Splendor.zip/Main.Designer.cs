﻿
namespace Splendor
{
    partial class Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Main));
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.st12 = new System.Windows.Forms.PictureBox();
            this.st13 = new System.Windows.Forms.PictureBox();
            this.st14 = new System.Windows.Forms.PictureBox();
            this.st15 = new System.Windows.Forms.PictureBox();
            this.st0 = new System.Windows.Forms.PictureBox();
            this.st3 = new System.Windows.Forms.PictureBox();
            this.st2 = new System.Windows.Forms.PictureBox();
            this.st1 = new System.Windows.Forms.PictureBox();
            this.st4 = new System.Windows.Forms.PictureBox();
            this.st5 = new System.Windows.Forms.PictureBox();
            this.st6 = new System.Windows.Forms.PictureBox();
            this.st7 = new System.Windows.Forms.PictureBox();
            this.st8 = new System.Windows.Forms.PictureBox();
            this.st9 = new System.Windows.Forms.PictureBox();
            this.st10 = new System.Windows.Forms.PictureBox();
            this.st11 = new System.Windows.Forms.PictureBox();
            this.keep1 = new System.Windows.Forms.PictureBox();
            this.keep0 = new System.Windows.Forms.PictureBox();
            this.keep2 = new System.Windows.Forms.PictureBox();
            this.buy0 = new System.Windows.Forms.PictureBox();
            this.buy1 = new System.Windows.Forms.PictureBox();
            this.buy2 = new System.Windows.Forms.PictureBox();
            this.buy3 = new System.Windows.Forms.PictureBox();
            this.gameout = new System.Windows.Forms.Label();
            this.pic_player1 = new System.Windows.Forms.PictureBox();
            this.player1 = new System.Windows.Forms.Label();
            this.player2 = new System.Windows.Forms.Label();
            this.pic_player2 = new System.Windows.Forms.PictureBox();
            this.player3 = new System.Windows.Forms.Label();
            this.pic_player3 = new System.Windows.Forms.PictureBox();
            this.player4 = new System.Windows.Forms.Label();
            this.pic_player4 = new System.Windows.Forms.PictureBox();
            this.start = new System.Windows.Forms.Label();
            this.buy = new System.Windows.Forms.Label();
            this.keep = new System.Windows.Forms.Label();
            this.stick = new System.Windows.Forms.Label();
            this.ok = new System.Windows.Forms.Label();
            this.back = new System.Windows.Forms.Label();
            this.stick2 = new System.Windows.Forms.Label();
            this.selectTokens = new System.Windows.Forms.Label();
            this.red = new System.Windows.Forms.Label();
            this.green = new System.Windows.Forms.Label();
            this.blue = new System.Windows.Forms.Label();
            this.white = new System.Windows.Forms.Label();
            this.black = new System.Windows.Forms.Label();
            this.gold = new System.Windows.Forms.Label();
            this.per_rd = new System.Windows.Forms.Label();
            this.rd = new System.Windows.Forms.Label();
            this.per_gn = new System.Windows.Forms.Label();
            this.gn = new System.Windows.Forms.Label();
            this.per_be = new System.Windows.Forms.Label();
            this.be = new System.Windows.Forms.Label();
            this.per_wt = new System.Windows.Forms.Label();
            this.wt = new System.Windows.Forms.Label();
            this.per_bk = new System.Windows.Forms.Label();
            this.bk = new System.Windows.Forms.Label();
            this.gd = new System.Windows.Forms.Label();
            this.pr1pt = new System.Windows.Forms.Label();
            this.pr1tk2 = new System.Windows.Forms.Label();
            this.pr2tk1 = new System.Windows.Forms.Label();
            this.pr2tk2 = new System.Windows.Forms.Label();
            this.pr3tk1 = new System.Windows.Forms.Label();
            this.pr3tk2 = new System.Windows.Forms.Label();
            this.pr4tk1 = new System.Windows.Forms.Label();
            this.pr4tk2 = new System.Windows.Forms.Label();
            this.pr1pb1 = new System.Windows.Forms.PictureBox();
            this.pr1pb2 = new System.Windows.Forms.PictureBox();
            this.pr1pb3 = new System.Windows.Forms.PictureBox();
            this.pr2pb1 = new System.Windows.Forms.PictureBox();
            this.pr2pb2 = new System.Windows.Forms.PictureBox();
            this.pr2pb3 = new System.Windows.Forms.PictureBox();
            this.pr3pb1 = new System.Windows.Forms.PictureBox();
            this.pr3pb2 = new System.Windows.Forms.PictureBox();
            this.pr3pb3 = new System.Windows.Forms.PictureBox();
            this.pr4pb1 = new System.Windows.Forms.PictureBox();
            this.pr4pb2 = new System.Windows.Forms.PictureBox();
            this.pr4pb3 = new System.Windows.Forms.PictureBox();
            this.pr1tk1 = new System.Windows.Forms.Label();
            this.pr1cards = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.pr2pt = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.pr2cards = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.pr3pt = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.pr3cards = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.pr4pt = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.pr4cards = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.timer = new System.Windows.Forms.Label();
            this.p1pic = new System.Windows.Forms.PictureBox();
            this.p2pic = new System.Windows.Forms.PictureBox();
            this.p3pic = new System.Windows.Forms.PictureBox();
            this.p4pic = new System.Windows.Forms.PictureBox();
            this.emoticon1 = new System.Windows.Forms.PictureBox();
            this.emoticon2 = new System.Windows.Forms.PictureBox();
            this.emoticon3 = new System.Windows.Forms.PictureBox();
            this.emoticon4 = new System.Windows.Forms.PictureBox();
            this.emoticon6 = new System.Windows.Forms.PictureBox();
            this.emoticon5 = new System.Windows.Forms.PictureBox();
            this.emoticon7 = new System.Windows.Forms.PictureBox();
            this.emoticon8 = new System.Windows.Forms.PictureBox();
            this.emoticon9 = new System.Windows.Forms.PictureBox();
            this.label4 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.st12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.st13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.st14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.st15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.st0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.st3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.st2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.st1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.st4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.st5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.st6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.st7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.st8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.st9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.st10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.st11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.keep1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.keep0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.keep2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.buy0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.buy1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.buy2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.buy3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_player1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_player2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_player3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_player4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pr1pb1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pr1pb2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pr1pb3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pr2pb1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pr2pb2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pr2pb3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pr3pb1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pr3pb2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pr3pb3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pr4pb1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pr4pb2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pr4pb3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.p1pic)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.p2pic)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.p3pic)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.p4pic)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emoticon1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emoticon2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emoticon3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emoticon4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emoticon6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emoticon5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emoticon7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emoticon8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emoticon9)).BeginInit();
            this.SuspendLayout();
            // 
            // listBox1
            // 
            this.listBox1.BackColor = System.Drawing.Color.LightSteelBlue;
            this.listBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.listBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listBox1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 24;
            this.listBox1.Location = new System.Drawing.Point(17, 338);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(294, 168);
            this.listBox1.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label1.ForeColor = System.Drawing.Color.LightSteelBlue;
            this.label1.Location = new System.Drawing.Point(12, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(115, 24);
            this.label1.TabIndex = 1;
            this.label1.Text = "RoomCode";
            // 
            // st12
            // 
            this.st12.InitialImage = null;
            this.st12.Location = new System.Drawing.Point(862, 96);
            this.st12.Name = "st12";
            this.st12.Size = new System.Drawing.Size(98, 98);
            this.st12.TabIndex = 2;
            this.st12.TabStop = false;
            this.st12.Click += new System.EventHandler(this.st12_Click);
            // 
            // st13
            // 
            this.st13.Location = new System.Drawing.Point(862, 205);
            this.st13.Name = "st13";
            this.st13.Size = new System.Drawing.Size(98, 98);
            this.st13.TabIndex = 2;
            this.st13.TabStop = false;
            this.st13.Click += new System.EventHandler(this.st13_Click);
            // 
            // st14
            // 
            this.st14.Location = new System.Drawing.Point(862, 314);
            this.st14.Name = "st14";
            this.st14.Size = new System.Drawing.Size(98, 98);
            this.st14.TabIndex = 2;
            this.st14.TabStop = false;
            this.st14.Click += new System.EventHandler(this.st14_Click);
            // 
            // st15
            // 
            this.st15.Location = new System.Drawing.Point(862, 423);
            this.st15.Name = "st15";
            this.st15.Size = new System.Drawing.Size(98, 98);
            this.st15.TabIndex = 2;
            this.st15.TabStop = false;
            this.st15.Click += new System.EventHandler(this.st15_Click);
            // 
            // st0
            // 
            this.st0.Location = new System.Drawing.Point(454, 96);
            this.st0.Name = "st0";
            this.st0.Size = new System.Drawing.Size(98, 137);
            this.st0.TabIndex = 2;
            this.st0.TabStop = false;
            this.st0.Click += new System.EventHandler(this.st0_Click);
            // 
            // st3
            // 
            this.st3.Location = new System.Drawing.Point(760, 96);
            this.st3.Name = "st3";
            this.st3.Size = new System.Drawing.Size(98, 137);
            this.st3.TabIndex = 2;
            this.st3.TabStop = false;
            this.st3.Click += new System.EventHandler(this.st3_Click);
            // 
            // st2
            // 
            this.st2.Location = new System.Drawing.Point(658, 96);
            this.st2.Name = "st2";
            this.st2.Size = new System.Drawing.Size(98, 137);
            this.st2.TabIndex = 2;
            this.st2.TabStop = false;
            this.st2.Click += new System.EventHandler(this.st2_Click);
            // 
            // st1
            // 
            this.st1.Location = new System.Drawing.Point(556, 96);
            this.st1.Name = "st1";
            this.st1.Size = new System.Drawing.Size(98, 137);
            this.st1.TabIndex = 2;
            this.st1.TabStop = false;
            this.st1.Click += new System.EventHandler(this.st1_Click);
            // 
            // st4
            // 
            this.st4.Location = new System.Drawing.Point(454, 240);
            this.st4.Name = "st4";
            this.st4.Size = new System.Drawing.Size(98, 137);
            this.st4.TabIndex = 2;
            this.st4.TabStop = false;
            this.st4.Click += new System.EventHandler(this.st4_Click);
            // 
            // st5
            // 
            this.st5.Location = new System.Drawing.Point(556, 240);
            this.st5.Name = "st5";
            this.st5.Size = new System.Drawing.Size(98, 137);
            this.st5.TabIndex = 2;
            this.st5.TabStop = false;
            this.st5.Click += new System.EventHandler(this.st5_Click);
            // 
            // st6
            // 
            this.st6.Location = new System.Drawing.Point(658, 240);
            this.st6.Name = "st6";
            this.st6.Size = new System.Drawing.Size(98, 137);
            this.st6.TabIndex = 2;
            this.st6.TabStop = false;
            this.st6.Click += new System.EventHandler(this.st6_Click);
            // 
            // st7
            // 
            this.st7.Location = new System.Drawing.Point(760, 240);
            this.st7.Name = "st7";
            this.st7.Size = new System.Drawing.Size(98, 137);
            this.st7.TabIndex = 2;
            this.st7.TabStop = false;
            this.st7.Click += new System.EventHandler(this.st7_Click);
            // 
            // st8
            // 
            this.st8.Location = new System.Drawing.Point(454, 384);
            this.st8.Name = "st8";
            this.st8.Size = new System.Drawing.Size(98, 137);
            this.st8.TabIndex = 2;
            this.st8.TabStop = false;
            this.st8.Click += new System.EventHandler(this.st8_Click);
            // 
            // st9
            // 
            this.st9.Location = new System.Drawing.Point(556, 384);
            this.st9.Name = "st9";
            this.st9.Size = new System.Drawing.Size(98, 137);
            this.st9.TabIndex = 2;
            this.st9.TabStop = false;
            this.st9.Click += new System.EventHandler(this.st9_Click);
            // 
            // st10
            // 
            this.st10.Location = new System.Drawing.Point(658, 384);
            this.st10.Name = "st10";
            this.st10.Size = new System.Drawing.Size(98, 137);
            this.st10.TabIndex = 2;
            this.st10.TabStop = false;
            this.st10.Click += new System.EventHandler(this.st10_Click);
            // 
            // st11
            // 
            this.st11.Location = new System.Drawing.Point(760, 384);
            this.st11.Name = "st11";
            this.st11.Size = new System.Drawing.Size(98, 137);
            this.st11.TabIndex = 2;
            this.st11.TabStop = false;
            this.st11.Click += new System.EventHandler(this.st11_Click);
            // 
            // keep1
            // 
            this.keep1.BackColor = System.Drawing.Color.Transparent;
            this.keep1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.keep1.Location = new System.Drawing.Point(406, 604);
            this.keep1.Name = "keep1";
            this.keep1.Size = new System.Drawing.Size(98, 137);
            this.keep1.TabIndex = 2;
            this.keep1.TabStop = false;
            this.keep1.Click += new System.EventHandler(this.keep1_Click);
            // 
            // keep0
            // 
            this.keep0.BackColor = System.Drawing.Color.Transparent;
            this.keep0.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.keep0.Location = new System.Drawing.Point(307, 604);
            this.keep0.Name = "keep0";
            this.keep0.Size = new System.Drawing.Size(98, 137);
            this.keep0.TabIndex = 2;
            this.keep0.TabStop = false;
            this.keep0.Click += new System.EventHandler(this.keep0_Click);
            // 
            // keep2
            // 
            this.keep2.BackColor = System.Drawing.Color.Transparent;
            this.keep2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.keep2.Location = new System.Drawing.Point(505, 604);
            this.keep2.Name = "keep2";
            this.keep2.Size = new System.Drawing.Size(98, 137);
            this.keep2.TabIndex = 2;
            this.keep2.TabStop = false;
            this.keep2.Click += new System.EventHandler(this.keep2_Click);
            // 
            // buy0
            // 
            this.buy0.BackColor = System.Drawing.Color.Transparent;
            this.buy0.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.buy0.Location = new System.Drawing.Point(605, 604);
            this.buy0.Name = "buy0";
            this.buy0.Size = new System.Drawing.Size(98, 98);
            this.buy0.TabIndex = 2;
            this.buy0.TabStop = false;
            this.buy0.Click += new System.EventHandler(this.buy0_Click);
            // 
            // buy1
            // 
            this.buy1.BackColor = System.Drawing.Color.Transparent;
            this.buy1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.buy1.Location = new System.Drawing.Point(704, 604);
            this.buy1.Name = "buy1";
            this.buy1.Size = new System.Drawing.Size(98, 98);
            this.buy1.TabIndex = 2;
            this.buy1.TabStop = false;
            this.buy1.Click += new System.EventHandler(this.buy1_Click);
            // 
            // buy2
            // 
            this.buy2.BackColor = System.Drawing.Color.Transparent;
            this.buy2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.buy2.Location = new System.Drawing.Point(803, 604);
            this.buy2.Name = "buy2";
            this.buy2.Size = new System.Drawing.Size(98, 98);
            this.buy2.TabIndex = 2;
            this.buy2.TabStop = false;
            this.buy2.Click += new System.EventHandler(this.buy2_Click);
            // 
            // buy3
            // 
            this.buy3.BackColor = System.Drawing.Color.Transparent;
            this.buy3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.buy3.Location = new System.Drawing.Point(902, 604);
            this.buy3.Name = "buy3";
            this.buy3.Size = new System.Drawing.Size(98, 98);
            this.buy3.TabIndex = 2;
            this.buy3.TabStop = false;
            this.buy3.Click += new System.EventHandler(this.buy3_Click);
            // 
            // gameout
            // 
            this.gameout.BackColor = System.Drawing.Color.Transparent;
            this.gameout.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.gameout.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.gameout.ForeColor = System.Drawing.SystemColors.InactiveCaption;
            this.gameout.Location = new System.Drawing.Point(233, 13);
            this.gameout.Name = "gameout";
            this.gameout.Size = new System.Drawing.Size(87, 27);
            this.gameout.TabIndex = 6;
            this.gameout.Text = "퇴장하기";
            this.gameout.Click += new System.EventHandler(this.gameout_Click);
            // 
            // pic_player1
            // 
            this.pic_player1.BackColor = System.Drawing.Color.Transparent;
            this.pic_player1.Location = new System.Drawing.Point(17, 99);
            this.pic_player1.Name = "pic_player1";
            this.pic_player1.Size = new System.Drawing.Size(27, 28);
            this.pic_player1.TabIndex = 7;
            this.pic_player1.TabStop = false;
            // 
            // player1
            // 
            this.player1.BackColor = System.Drawing.Color.Transparent;
            this.player1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.player1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.player1.ForeColor = System.Drawing.SystemColors.InactiveCaption;
            this.player1.Location = new System.Drawing.Point(50, 99);
            this.player1.Name = "player1";
            this.player1.Size = new System.Drawing.Size(170, 28);
            this.player1.TabIndex = 6;
            this.player1.Text = "Player1";
            // 
            // player2
            // 
            this.player2.BackColor = System.Drawing.Color.Transparent;
            this.player2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.player2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.player2.ForeColor = System.Drawing.SystemColors.InactiveCaption;
            this.player2.Location = new System.Drawing.Point(1071, 32);
            this.player2.Name = "player2";
            this.player2.Size = new System.Drawing.Size(170, 28);
            this.player2.TabIndex = 6;
            this.player2.Text = "Player2";
            // 
            // pic_player2
            // 
            this.pic_player2.BackColor = System.Drawing.Color.Transparent;
            this.pic_player2.Location = new System.Drawing.Point(1038, 32);
            this.pic_player2.Name = "pic_player2";
            this.pic_player2.Size = new System.Drawing.Size(27, 28);
            this.pic_player2.TabIndex = 7;
            this.pic_player2.TabStop = false;
            // 
            // player3
            // 
            this.player3.BackColor = System.Drawing.Color.Transparent;
            this.player3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.player3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.player3.ForeColor = System.Drawing.SystemColors.InactiveCaption;
            this.player3.Location = new System.Drawing.Point(1071, 279);
            this.player3.Name = "player3";
            this.player3.Size = new System.Drawing.Size(170, 28);
            this.player3.TabIndex = 6;
            this.player3.Text = "Player3";
            // 
            // pic_player3
            // 
            this.pic_player3.BackColor = System.Drawing.Color.Transparent;
            this.pic_player3.Location = new System.Drawing.Point(1038, 279);
            this.pic_player3.Name = "pic_player3";
            this.pic_player3.Size = new System.Drawing.Size(27, 28);
            this.pic_player3.TabIndex = 7;
            this.pic_player3.TabStop = false;
            // 
            // player4
            // 
            this.player4.BackColor = System.Drawing.Color.Transparent;
            this.player4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.player4.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.player4.ForeColor = System.Drawing.SystemColors.InactiveCaption;
            this.player4.Location = new System.Drawing.Point(1071, 528);
            this.player4.Name = "player4";
            this.player4.Size = new System.Drawing.Size(170, 28);
            this.player4.TabIndex = 6;
            this.player4.Text = "Player4";
            // 
            // pic_player4
            // 
            this.pic_player4.BackColor = System.Drawing.Color.Transparent;
            this.pic_player4.Location = new System.Drawing.Point(1038, 528);
            this.pic_player4.Name = "pic_player4";
            this.pic_player4.Size = new System.Drawing.Size(27, 28);
            this.pic_player4.TabIndex = 7;
            this.pic_player4.TabStop = false;
            // 
            // start
            // 
            this.start.BackColor = System.Drawing.Color.Transparent;
            this.start.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.start.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.start.ForeColor = System.Drawing.SystemColors.InactiveCaption;
            this.start.Location = new System.Drawing.Point(142, 12);
            this.start.Name = "start";
            this.start.Size = new System.Drawing.Size(98, 28);
            this.start.TabIndex = 6;
            this.start.Text = "준비하기";
            this.start.Click += new System.EventHandler(this.start_Click_1);
            // 
            // buy
            // 
            this.buy.BackColor = System.Drawing.Color.Transparent;
            this.buy.Enabled = false;
            this.buy.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buy.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.buy.ForeColor = System.Drawing.SystemColors.InactiveCaption;
            this.buy.Location = new System.Drawing.Point(585, 35);
            this.buy.Name = "buy";
            this.buy.Size = new System.Drawing.Size(67, 28);
            this.buy.TabIndex = 6;
            this.buy.Text = "Buy";
            this.buy.Visible = false;
            this.buy.Click += new System.EventHandler(this.buy_Click);
            // 
            // keep
            // 
            this.keep.BackColor = System.Drawing.Color.Transparent;
            this.keep.Enabled = false;
            this.keep.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.keep.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.keep.ForeColor = System.Drawing.SystemColors.InactiveCaption;
            this.keep.Location = new System.Drawing.Point(677, 35);
            this.keep.Name = "keep";
            this.keep.Size = new System.Drawing.Size(91, 28);
            this.keep.TabIndex = 6;
            this.keep.Text = "Keep";
            this.keep.Visible = false;
            this.keep.Click += new System.EventHandler(this.keep_Click);
            // 
            // stick
            // 
            this.stick.BackColor = System.Drawing.Color.Transparent;
            this.stick.Enabled = false;
            this.stick.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.stick.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.stick.ForeColor = System.Drawing.SystemColors.InactiveCaption;
            this.stick.Location = new System.Drawing.Point(647, 32);
            this.stick.Name = "stick";
            this.stick.Size = new System.Drawing.Size(24, 28);
            this.stick.TabIndex = 6;
            this.stick.Text = ".";
            this.stick.Visible = false;
            this.stick.Click += new System.EventHandler(this.stick_Click);
            // 
            // ok
            // 
            this.ok.BackColor = System.Drawing.Color.Transparent;
            this.ok.Enabled = false;
            this.ok.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ok.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.ok.ForeColor = System.Drawing.SystemColors.InactiveCaption;
            this.ok.Location = new System.Drawing.Point(585, 68);
            this.ok.Name = "ok";
            this.ok.Size = new System.Drawing.Size(67, 28);
            this.ok.TabIndex = 6;
            this.ok.Text = "OK";
            this.ok.Visible = false;
            this.ok.Click += new System.EventHandler(this.label2_Click);
            // 
            // back
            // 
            this.back.BackColor = System.Drawing.Color.Transparent;
            this.back.Enabled = false;
            this.back.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.back.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.back.ForeColor = System.Drawing.SystemColors.InactiveCaption;
            this.back.Location = new System.Drawing.Point(679, 68);
            this.back.Margin = new System.Windows.Forms.Padding(0);
            this.back.Name = "back";
            this.back.Size = new System.Drawing.Size(91, 28);
            this.back.TabIndex = 6;
            this.back.Text = "Back";
            this.back.Visible = false;
            this.back.Click += new System.EventHandler(this.label3_Click);
            // 
            // stick2
            // 
            this.stick2.BackColor = System.Drawing.Color.Transparent;
            this.stick2.Enabled = false;
            this.stick2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.stick2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.stick2.ForeColor = System.Drawing.SystemColors.InactiveCaption;
            this.stick2.Location = new System.Drawing.Point(647, 65);
            this.stick2.Name = "stick2";
            this.stick2.Size = new System.Drawing.Size(24, 28);
            this.stick2.TabIndex = 6;
            this.stick2.Text = ".";
            this.stick2.Visible = false;
            this.stick2.Click += new System.EventHandler(this.stick2_Click);
            // 
            // selectTokens
            // 
            this.selectTokens.BackColor = System.Drawing.Color.Transparent;
            this.selectTokens.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.selectTokens.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.selectTokens.ForeColor = System.Drawing.SystemColors.InactiveCaption;
            this.selectTokens.Location = new System.Drawing.Point(523, 3);
            this.selectTokens.Name = "selectTokens";
            this.selectTokens.Size = new System.Drawing.Size(268, 28);
            this.selectTokens.TabIndex = 6;
            this.selectTokens.Text = "Select";
            this.selectTokens.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.selectTokens.Visible = false;
            this.selectTokens.Click += new System.EventHandler(this.selectTokens_Click);
            // 
            // red
            // 
            this.red.BackColor = System.Drawing.Color.Transparent;
            this.red.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.red.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.red.Image = global::Splendor.Properties.Resources.IMG_0586_6;
            this.red.Location = new System.Drawing.Point(382, 109);
            this.red.Name = "red";
            this.red.Size = new System.Drawing.Size(66, 66);
            this.red.TabIndex = 8;
            this.red.Text = "-";
            this.red.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.red.Click += new System.EventHandler(this.red_Click);
            // 
            // green
            // 
            this.green.BackColor = System.Drawing.Color.Transparent;
            this.green.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.green.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.green.Image = global::Splendor.Properties.Resources.IMG_0586_5;
            this.green.Location = new System.Drawing.Point(382, 175);
            this.green.Name = "green";
            this.green.Size = new System.Drawing.Size(66, 66);
            this.green.TabIndex = 8;
            this.green.Text = "-";
            this.green.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.green.Click += new System.EventHandler(this.green_Click);
            // 
            // blue
            // 
            this.blue.BackColor = System.Drawing.Color.Transparent;
            this.blue.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.blue.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.blue.Image = global::Splendor.Properties.Resources.IMG_0586_7;
            this.blue.Location = new System.Drawing.Point(382, 241);
            this.blue.Name = "blue";
            this.blue.Size = new System.Drawing.Size(66, 66);
            this.blue.TabIndex = 8;
            this.blue.Text = "-";
            this.blue.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.blue.Click += new System.EventHandler(this.blue_Click);
            // 
            // white
            // 
            this.white.BackColor = System.Drawing.Color.Transparent;
            this.white.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.white.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(68)))), ((int)(((byte)(116)))));
            this.white.Image = global::Splendor.Properties.Resources.IMG_0586_2;
            this.white.Location = new System.Drawing.Point(382, 306);
            this.white.Name = "white";
            this.white.Size = new System.Drawing.Size(66, 66);
            this.white.TabIndex = 8;
            this.white.Text = "-";
            this.white.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.white.Click += new System.EventHandler(this.white_Click);
            // 
            // black
            // 
            this.black.BackColor = System.Drawing.Color.Transparent;
            this.black.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.black.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.black.Image = global::Splendor.Properties.Resources.IMG_0586_4;
            this.black.Location = new System.Drawing.Point(382, 372);
            this.black.Name = "black";
            this.black.Size = new System.Drawing.Size(66, 66);
            this.black.TabIndex = 8;
            this.black.Text = "-";
            this.black.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.black.Click += new System.EventHandler(this.black_Click);
            // 
            // gold
            // 
            this.gold.BackColor = System.Drawing.Color.Transparent;
            this.gold.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.gold.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.gold.Image = global::Splendor.Properties.Resources.IMG_0586_3;
            this.gold.Location = new System.Drawing.Point(382, 438);
            this.gold.Name = "gold";
            this.gold.Size = new System.Drawing.Size(66, 66);
            this.gold.TabIndex = 8;
            this.gold.Text = "-";
            this.gold.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.gold.Click += new System.EventHandler(this.gold_Click);
            // 
            // per_rd
            // 
            this.per_rd.BackColor = System.Drawing.Color.Transparent;
            this.per_rd.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.per_rd.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.per_rd.Image = global::Splendor.Properties.Resources.IMG_0586_6;
            this.per_rd.Location = new System.Drawing.Point(287, 528);
            this.per_rd.Name = "per_rd";
            this.per_rd.Size = new System.Drawing.Size(66, 66);
            this.per_rd.TabIndex = 8;
            this.per_rd.Text = "-";
            this.per_rd.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.per_rd.Click += new System.EventHandler(this.per_rd_Click);
            // 
            // rd
            // 
            this.rd.BackColor = System.Drawing.Color.Transparent;
            this.rd.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.rd.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.rd.Image = global::Splendor.Properties.Resources.IMG_0586_6;
            this.rd.Location = new System.Drawing.Point(353, 528);
            this.rd.Name = "rd";
            this.rd.Size = new System.Drawing.Size(66, 66);
            this.rd.TabIndex = 8;
            this.rd.Text = "-";
            this.rd.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rd.Click += new System.EventHandler(this.rd_Click);
            // 
            // per_gn
            // 
            this.per_gn.BackColor = System.Drawing.Color.Transparent;
            this.per_gn.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.per_gn.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.per_gn.Image = global::Splendor.Properties.Resources.IMG_0586_5;
            this.per_gn.Location = new System.Drawing.Point(419, 528);
            this.per_gn.Name = "per_gn";
            this.per_gn.Size = new System.Drawing.Size(66, 66);
            this.per_gn.TabIndex = 8;
            this.per_gn.Text = "-";
            this.per_gn.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.per_gn.Click += new System.EventHandler(this.per_gn_Click);
            // 
            // gn
            // 
            this.gn.BackColor = System.Drawing.Color.Transparent;
            this.gn.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.gn.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.gn.Image = global::Splendor.Properties.Resources.IMG_0586_5;
            this.gn.Location = new System.Drawing.Point(485, 528);
            this.gn.Name = "gn";
            this.gn.Size = new System.Drawing.Size(66, 66);
            this.gn.TabIndex = 8;
            this.gn.Text = "-";
            this.gn.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.gn.Click += new System.EventHandler(this.gn_Click);
            // 
            // per_be
            // 
            this.per_be.BackColor = System.Drawing.Color.Transparent;
            this.per_be.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.per_be.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.per_be.Image = global::Splendor.Properties.Resources.IMG_0586_7;
            this.per_be.Location = new System.Drawing.Point(551, 528);
            this.per_be.Name = "per_be";
            this.per_be.Size = new System.Drawing.Size(66, 66);
            this.per_be.TabIndex = 8;
            this.per_be.Text = "-";
            this.per_be.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.per_be.Click += new System.EventHandler(this.per_be_Click);
            // 
            // be
            // 
            this.be.BackColor = System.Drawing.Color.Transparent;
            this.be.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.be.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.be.Image = global::Splendor.Properties.Resources.IMG_0586_7;
            this.be.Location = new System.Drawing.Point(617, 528);
            this.be.Name = "be";
            this.be.Size = new System.Drawing.Size(66, 66);
            this.be.TabIndex = 8;
            this.be.Text = "-";
            this.be.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.be.Click += new System.EventHandler(this.be_Click);
            // 
            // per_wt
            // 
            this.per_wt.BackColor = System.Drawing.Color.Transparent;
            this.per_wt.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.per_wt.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(68)))), ((int)(((byte)(116)))));
            this.per_wt.Image = global::Splendor.Properties.Resources.IMG_0586_2;
            this.per_wt.Location = new System.Drawing.Point(683, 528);
            this.per_wt.Name = "per_wt";
            this.per_wt.Size = new System.Drawing.Size(66, 66);
            this.per_wt.TabIndex = 8;
            this.per_wt.Text = "-";
            this.per_wt.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.per_wt.Click += new System.EventHandler(this.per_wt_Click);
            // 
            // wt
            // 
            this.wt.BackColor = System.Drawing.Color.Transparent;
            this.wt.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.wt.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(68)))), ((int)(((byte)(116)))));
            this.wt.Image = global::Splendor.Properties.Resources.IMG_0586_2;
            this.wt.Location = new System.Drawing.Point(749, 528);
            this.wt.Name = "wt";
            this.wt.Size = new System.Drawing.Size(66, 66);
            this.wt.TabIndex = 8;
            this.wt.Text = "-";
            this.wt.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.wt.Click += new System.EventHandler(this.wt_Click);
            // 
            // per_bk
            // 
            this.per_bk.BackColor = System.Drawing.Color.Transparent;
            this.per_bk.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.per_bk.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.per_bk.Image = global::Splendor.Properties.Resources.IMG_0586_4;
            this.per_bk.Location = new System.Drawing.Point(815, 528);
            this.per_bk.Name = "per_bk";
            this.per_bk.Size = new System.Drawing.Size(66, 66);
            this.per_bk.TabIndex = 8;
            this.per_bk.Text = "-";
            this.per_bk.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.per_bk.Click += new System.EventHandler(this.per_bk_Click);
            // 
            // bk
            // 
            this.bk.BackColor = System.Drawing.Color.Transparent;
            this.bk.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.bk.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.bk.Image = global::Splendor.Properties.Resources.IMG_0586_4;
            this.bk.Location = new System.Drawing.Point(881, 528);
            this.bk.Name = "bk";
            this.bk.Size = new System.Drawing.Size(66, 66);
            this.bk.TabIndex = 8;
            this.bk.Text = "-";
            this.bk.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bk.Click += new System.EventHandler(this.bk_Click);
            // 
            // gd
            // 
            this.gd.BackColor = System.Drawing.Color.Transparent;
            this.gd.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.gd.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.gd.Image = global::Splendor.Properties.Resources.IMG_0586_3;
            this.gd.Location = new System.Drawing.Point(947, 528);
            this.gd.Name = "gd";
            this.gd.Size = new System.Drawing.Size(66, 66);
            this.gd.TabIndex = 8;
            this.gd.Text = "-";
            this.gd.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.gd.Click += new System.EventHandler(this.gd_Click);
            // 
            // pr1pt
            // 
            this.pr1pt.BackColor = System.Drawing.Color.Transparent;
            this.pr1pt.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.pr1pt.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.pr1pt.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.pr1pt.Location = new System.Drawing.Point(310, 124);
            this.pr1pt.Name = "pr1pt";
            this.pr1pt.Size = new System.Drawing.Size(39, 32);
            this.pr1pt.TabIndex = 8;
            this.pr1pt.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.pr1pt.Click += new System.EventHandler(this.pr1pt_Click);
            // 
            // pr1tk2
            // 
            this.pr1tk2.BackColor = System.Drawing.Color.Transparent;
            this.pr1tk2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.pr1tk2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.pr1tk2.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.pr1tk2.Image = global::Splendor.Properties.Resources.img_jewel4;
            this.pr1tk2.Location = new System.Drawing.Point(75, 160);
            this.pr1tk2.Name = "pr1tk2";
            this.pr1tk2.Size = new System.Drawing.Size(206, 32);
            this.pr1tk2.TabIndex = 8;
            this.pr1tk2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pr2tk1
            // 
            this.pr2tk1.BackColor = System.Drawing.Color.Transparent;
            this.pr2tk1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.pr2tk1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.pr2tk1.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.pr2tk1.Image = global::Splendor.Properties.Resources.img_jewel3;
            this.pr2tk1.Location = new System.Drawing.Point(1096, 61);
            this.pr2tk1.Name = "pr2tk1";
            this.pr2tk1.Size = new System.Drawing.Size(206, 32);
            this.pr2tk1.TabIndex = 8;
            this.pr2tk1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pr2tk2
            // 
            this.pr2tk2.BackColor = System.Drawing.Color.Transparent;
            this.pr2tk2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.pr2tk2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.pr2tk2.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.pr2tk2.Image = global::Splendor.Properties.Resources.img_jewel4;
            this.pr2tk2.Location = new System.Drawing.Point(1096, 93);
            this.pr2tk2.Name = "pr2tk2";
            this.pr2tk2.Size = new System.Drawing.Size(206, 32);
            this.pr2tk2.TabIndex = 8;
            this.pr2tk2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pr3tk1
            // 
            this.pr3tk1.BackColor = System.Drawing.Color.Transparent;
            this.pr3tk1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.pr3tk1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.pr3tk1.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.pr3tk1.Image = global::Splendor.Properties.Resources.img_jewel3;
            this.pr3tk1.Location = new System.Drawing.Point(1096, 308);
            this.pr3tk1.Name = "pr3tk1";
            this.pr3tk1.Size = new System.Drawing.Size(206, 32);
            this.pr3tk1.TabIndex = 8;
            this.pr3tk1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pr3tk2
            // 
            this.pr3tk2.BackColor = System.Drawing.Color.Transparent;
            this.pr3tk2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.pr3tk2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.pr3tk2.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.pr3tk2.Image = global::Splendor.Properties.Resources.img_jewel4;
            this.pr3tk2.Location = new System.Drawing.Point(1096, 340);
            this.pr3tk2.Name = "pr3tk2";
            this.pr3tk2.Size = new System.Drawing.Size(206, 32);
            this.pr3tk2.TabIndex = 8;
            this.pr3tk2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pr4tk1
            // 
            this.pr4tk1.BackColor = System.Drawing.Color.Transparent;
            this.pr4tk1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.pr4tk1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.pr4tk1.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.pr4tk1.Image = global::Splendor.Properties.Resources.img_jewel3;
            this.pr4tk1.Location = new System.Drawing.Point(1096, 557);
            this.pr4tk1.Name = "pr4tk1";
            this.pr4tk1.Size = new System.Drawing.Size(206, 32);
            this.pr4tk1.TabIndex = 8;
            this.pr4tk1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pr4tk2
            // 
            this.pr4tk2.BackColor = System.Drawing.Color.Transparent;
            this.pr4tk2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.pr4tk2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.pr4tk2.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.pr4tk2.Image = global::Splendor.Properties.Resources.img_jewel4;
            this.pr4tk2.Location = new System.Drawing.Point(1096, 589);
            this.pr4tk2.Name = "pr4tk2";
            this.pr4tk2.Size = new System.Drawing.Size(206, 32);
            this.pr4tk2.TabIndex = 8;
            this.pr4tk2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pr1pb1
            // 
            this.pr1pb1.BackColor = System.Drawing.Color.Transparent;
            this.pr1pb1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pr1pb1.Location = new System.Drawing.Point(17, 193);
            this.pr1pb1.Name = "pr1pb1";
            this.pr1pb1.Size = new System.Drawing.Size(98, 137);
            this.pr1pb1.TabIndex = 9;
            this.pr1pb1.TabStop = false;
            // 
            // pr1pb2
            // 
            this.pr1pb2.BackColor = System.Drawing.Color.Transparent;
            this.pr1pb2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pr1pb2.Location = new System.Drawing.Point(115, 193);
            this.pr1pb2.Name = "pr1pb2";
            this.pr1pb2.Size = new System.Drawing.Size(98, 137);
            this.pr1pb2.TabIndex = 9;
            this.pr1pb2.TabStop = false;
            // 
            // pr1pb3
            // 
            this.pr1pb3.BackColor = System.Drawing.Color.Transparent;
            this.pr1pb3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pr1pb3.Location = new System.Drawing.Point(213, 193);
            this.pr1pb3.Name = "pr1pb3";
            this.pr1pb3.Size = new System.Drawing.Size(98, 137);
            this.pr1pb3.TabIndex = 9;
            this.pr1pb3.TabStop = false;
            // 
            // pr2pb1
            // 
            this.pr2pb1.BackColor = System.Drawing.Color.Transparent;
            this.pr2pb1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pr2pb1.Location = new System.Drawing.Point(1038, 126);
            this.pr2pb1.Name = "pr2pb1";
            this.pr2pb1.Size = new System.Drawing.Size(98, 137);
            this.pr2pb1.TabIndex = 9;
            this.pr2pb1.TabStop = false;
            // 
            // pr2pb2
            // 
            this.pr2pb2.BackColor = System.Drawing.Color.Transparent;
            this.pr2pb2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pr2pb2.Location = new System.Drawing.Point(1136, 126);
            this.pr2pb2.Name = "pr2pb2";
            this.pr2pb2.Size = new System.Drawing.Size(98, 137);
            this.pr2pb2.TabIndex = 9;
            this.pr2pb2.TabStop = false;
            // 
            // pr2pb3
            // 
            this.pr2pb3.BackColor = System.Drawing.Color.Transparent;
            this.pr2pb3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pr2pb3.Location = new System.Drawing.Point(1234, 126);
            this.pr2pb3.Name = "pr2pb3";
            this.pr2pb3.Size = new System.Drawing.Size(98, 137);
            this.pr2pb3.TabIndex = 9;
            this.pr2pb3.TabStop = false;
            // 
            // pr3pb1
            // 
            this.pr3pb1.BackColor = System.Drawing.Color.Transparent;
            this.pr3pb1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pr3pb1.Location = new System.Drawing.Point(1038, 373);
            this.pr3pb1.Name = "pr3pb1";
            this.pr3pb1.Size = new System.Drawing.Size(98, 137);
            this.pr3pb1.TabIndex = 9;
            this.pr3pb1.TabStop = false;
            // 
            // pr3pb2
            // 
            this.pr3pb2.BackColor = System.Drawing.Color.Transparent;
            this.pr3pb2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pr3pb2.Location = new System.Drawing.Point(1136, 373);
            this.pr3pb2.Name = "pr3pb2";
            this.pr3pb2.Size = new System.Drawing.Size(98, 137);
            this.pr3pb2.TabIndex = 9;
            this.pr3pb2.TabStop = false;
            // 
            // pr3pb3
            // 
            this.pr3pb3.BackColor = System.Drawing.Color.Transparent;
            this.pr3pb3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pr3pb3.Location = new System.Drawing.Point(1234, 373);
            this.pr3pb3.Name = "pr3pb3";
            this.pr3pb3.Size = new System.Drawing.Size(98, 137);
            this.pr3pb3.TabIndex = 9;
            this.pr3pb3.TabStop = false;
            // 
            // pr4pb1
            // 
            this.pr4pb1.BackColor = System.Drawing.Color.Transparent;
            this.pr4pb1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pr4pb1.Location = new System.Drawing.Point(1038, 622);
            this.pr4pb1.Name = "pr4pb1";
            this.pr4pb1.Size = new System.Drawing.Size(98, 137);
            this.pr4pb1.TabIndex = 9;
            this.pr4pb1.TabStop = false;
            // 
            // pr4pb2
            // 
            this.pr4pb2.BackColor = System.Drawing.Color.Transparent;
            this.pr4pb2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pr4pb2.Location = new System.Drawing.Point(1136, 622);
            this.pr4pb2.Name = "pr4pb2";
            this.pr4pb2.Size = new System.Drawing.Size(98, 137);
            this.pr4pb2.TabIndex = 9;
            this.pr4pb2.TabStop = false;
            // 
            // pr4pb3
            // 
            this.pr4pb3.BackColor = System.Drawing.Color.Transparent;
            this.pr4pb3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pr4pb3.Location = new System.Drawing.Point(1234, 622);
            this.pr4pb3.Name = "pr4pb3";
            this.pr4pb3.Size = new System.Drawing.Size(98, 137);
            this.pr4pb3.TabIndex = 9;
            this.pr4pb3.TabStop = false;
            // 
            // pr1tk1
            // 
            this.pr1tk1.BackColor = System.Drawing.Color.Transparent;
            this.pr1tk1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.pr1tk1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.pr1tk1.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.pr1tk1.Image = global::Splendor.Properties.Resources.img_jewel3;
            this.pr1tk1.Location = new System.Drawing.Point(75, 128);
            this.pr1tk1.Name = "pr1tk1";
            this.pr1tk1.Size = new System.Drawing.Size(206, 32);
            this.pr1tk1.TabIndex = 8;
            this.pr1tk1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pr1cards
            // 
            this.pr1cards.BackColor = System.Drawing.Color.Transparent;
            this.pr1cards.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.pr1cards.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.pr1cards.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.pr1cards.Location = new System.Drawing.Point(310, 160);
            this.pr1cards.Name = "pr1cards";
            this.pr1cards.Size = new System.Drawing.Size(39, 32);
            this.pr1cards.TabIndex = 8;
            this.pr1cards.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label2.ForeColor = System.Drawing.Color.Gold;
            this.label2.Location = new System.Drawing.Point(278, 124);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(39, 32);
            this.label2.TabIndex = 8;
            this.label2.Text = "⭐";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label2.Click += new System.EventHandler(this.pr1pt_Click);
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.label3.Location = new System.Drawing.Point(278, 160);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(39, 32);
            this.label3.TabIndex = 8;
            this.label3.Text = "cards";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pr2pt
            // 
            this.pr2pt.BackColor = System.Drawing.Color.Transparent;
            this.pr2pt.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.pr2pt.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.pr2pt.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.pr2pt.Location = new System.Drawing.Point(1331, 54);
            this.pr2pt.Name = "pr2pt";
            this.pr2pt.Size = new System.Drawing.Size(39, 32);
            this.pr2pt.TabIndex = 8;
            this.pr2pt.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.pr2pt.Click += new System.EventHandler(this.pr1pt_Click);
            // 
            // label5
            // 
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label5.ForeColor = System.Drawing.Color.Gold;
            this.label5.Location = new System.Drawing.Point(1298, 54);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(39, 32);
            this.label5.TabIndex = 8;
            this.label5.Text = "⭐";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label5.Click += new System.EventHandler(this.pr1pt_Click);
            // 
            // pr2cards
            // 
            this.pr2cards.BackColor = System.Drawing.Color.Transparent;
            this.pr2cards.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.pr2cards.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.pr2cards.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.pr2cards.Location = new System.Drawing.Point(1331, 90);
            this.pr2cards.Name = "pr2cards";
            this.pr2cards.Size = new System.Drawing.Size(39, 32);
            this.pr2cards.TabIndex = 8;
            this.pr2cards.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label7
            // 
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.label7.Location = new System.Drawing.Point(1298, 90);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(39, 32);
            this.label7.TabIndex = 8;
            this.label7.Text = "cards";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pr3pt
            // 
            this.pr3pt.BackColor = System.Drawing.Color.Transparent;
            this.pr3pt.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.pr3pt.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.pr3pt.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.pr3pt.Location = new System.Drawing.Point(1332, 303);
            this.pr3pt.Name = "pr3pt";
            this.pr3pt.Size = new System.Drawing.Size(39, 32);
            this.pr3pt.TabIndex = 8;
            this.pr3pt.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.pr3pt.Click += new System.EventHandler(this.pr1pt_Click);
            // 
            // label9
            // 
            this.label9.BackColor = System.Drawing.Color.Transparent;
            this.label9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label9.ForeColor = System.Drawing.Color.Gold;
            this.label9.Location = new System.Drawing.Point(1299, 303);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(39, 32);
            this.label9.TabIndex = 8;
            this.label9.Text = "⭐";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label9.Click += new System.EventHandler(this.pr1pt_Click);
            // 
            // pr3cards
            // 
            this.pr3cards.BackColor = System.Drawing.Color.Transparent;
            this.pr3cards.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.pr3cards.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.pr3cards.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.pr3cards.Location = new System.Drawing.Point(1332, 339);
            this.pr3cards.Name = "pr3cards";
            this.pr3cards.Size = new System.Drawing.Size(39, 32);
            this.pr3cards.TabIndex = 8;
            this.pr3cards.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label11
            // 
            this.label11.BackColor = System.Drawing.Color.Transparent;
            this.label11.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.label11.Location = new System.Drawing.Point(1299, 339);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(39, 32);
            this.label11.TabIndex = 8;
            this.label11.Text = "cards";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pr4pt
            // 
            this.pr4pt.BackColor = System.Drawing.Color.Transparent;
            this.pr4pt.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.pr4pt.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.pr4pt.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.pr4pt.Location = new System.Drawing.Point(1332, 549);
            this.pr4pt.Name = "pr4pt";
            this.pr4pt.Size = new System.Drawing.Size(39, 32);
            this.pr4pt.TabIndex = 8;
            this.pr4pt.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.pr4pt.Click += new System.EventHandler(this.pr1pt_Click);
            // 
            // label13
            // 
            this.label13.BackColor = System.Drawing.Color.Transparent;
            this.label13.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label13.ForeColor = System.Drawing.Color.Gold;
            this.label13.Location = new System.Drawing.Point(1299, 549);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(39, 32);
            this.label13.TabIndex = 8;
            this.label13.Text = "⭐";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label13.Click += new System.EventHandler(this.pr1pt_Click);
            // 
            // pr4cards
            // 
            this.pr4cards.BackColor = System.Drawing.Color.Transparent;
            this.pr4cards.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.pr4cards.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.pr4cards.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.pr4cards.Location = new System.Drawing.Point(1332, 585);
            this.pr4cards.Name = "pr4cards";
            this.pr4cards.Size = new System.Drawing.Size(39, 32);
            this.pr4cards.TabIndex = 8;
            this.pr4cards.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label15
            // 
            this.label15.BackColor = System.Drawing.Color.Transparent;
            this.label15.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.label15.Location = new System.Drawing.Point(1299, 585);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(39, 32);
            this.label15.TabIndex = 8;
            this.label15.Text = "cards";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // timer
            // 
            this.timer.BackColor = System.Drawing.Color.Transparent;
            this.timer.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.timer.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.timer.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.timer.Location = new System.Drawing.Point(319, 13);
            this.timer.Name = "timer";
            this.timer.Size = new System.Drawing.Size(170, 28);
            this.timer.TabIndex = 6;
            this.timer.Text = "00:00";
            // 
            // p1pic
            // 
            this.p1pic.BackColor = System.Drawing.Color.Transparent;
            this.p1pic.Location = new System.Drawing.Point(17, 128);
            this.p1pic.Name = "p1pic";
            this.p1pic.Size = new System.Drawing.Size(64, 64);
            this.p1pic.TabIndex = 10;
            this.p1pic.TabStop = false;
            // 
            // p2pic
            // 
            this.p2pic.BackColor = System.Drawing.Color.Transparent;
            this.p2pic.Location = new System.Drawing.Point(1038, 61);
            this.p2pic.Name = "p2pic";
            this.p2pic.Size = new System.Drawing.Size(64, 64);
            this.p2pic.TabIndex = 11;
            this.p2pic.TabStop = false;
            // 
            // p3pic
            // 
            this.p3pic.BackColor = System.Drawing.Color.Transparent;
            this.p3pic.Location = new System.Drawing.Point(1038, 308);
            this.p3pic.Name = "p3pic";
            this.p3pic.Size = new System.Drawing.Size(64, 64);
            this.p3pic.TabIndex = 12;
            this.p3pic.TabStop = false;
            // 
            // p4pic
            // 
            this.p4pic.BackColor = System.Drawing.Color.Transparent;
            this.p4pic.Location = new System.Drawing.Point(1038, 557);
            this.p4pic.Name = "p4pic";
            this.p4pic.Size = new System.Drawing.Size(64, 64);
            this.p4pic.TabIndex = 13;
            this.p4pic.TabStop = false;
            // 
            // emoticon1
            // 
            this.emoticon1.BackColor = System.Drawing.Color.Transparent;
            this.emoticon1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.emoticon1.Image = global::Splendor.Properties.Resources._1;
            this.emoticon1.Location = new System.Drawing.Point(55, 539);
            this.emoticon1.Name = "emoticon1";
            this.emoticon1.Size = new System.Drawing.Size(64, 64);
            this.emoticon1.TabIndex = 14;
            this.emoticon1.TabStop = false;
            this.emoticon1.Click += new System.EventHandler(this.emoticon1_Click);
            // 
            // emoticon2
            // 
            this.emoticon2.BackColor = System.Drawing.Color.Transparent;
            this.emoticon2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.emoticon2.Image = global::Splendor.Properties.Resources._2;
            this.emoticon2.Location = new System.Drawing.Point(121, 539);
            this.emoticon2.Name = "emoticon2";
            this.emoticon2.Size = new System.Drawing.Size(64, 64);
            this.emoticon2.TabIndex = 15;
            this.emoticon2.TabStop = false;
            this.emoticon2.Click += new System.EventHandler(this.emoticon2_Click);
            // 
            // emoticon3
            // 
            this.emoticon3.BackColor = System.Drawing.Color.Transparent;
            this.emoticon3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.emoticon3.Image = global::Splendor.Properties.Resources._3;
            this.emoticon3.Location = new System.Drawing.Point(187, 539);
            this.emoticon3.Name = "emoticon3";
            this.emoticon3.Size = new System.Drawing.Size(64, 64);
            this.emoticon3.TabIndex = 16;
            this.emoticon3.TabStop = false;
            this.emoticon3.Click += new System.EventHandler(this.emoticon3_Click);
            // 
            // emoticon4
            // 
            this.emoticon4.BackColor = System.Drawing.Color.Transparent;
            this.emoticon4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.emoticon4.Image = global::Splendor.Properties.Resources._4;
            this.emoticon4.Location = new System.Drawing.Point(55, 605);
            this.emoticon4.Name = "emoticon4";
            this.emoticon4.Size = new System.Drawing.Size(64, 64);
            this.emoticon4.TabIndex = 17;
            this.emoticon4.TabStop = false;
            this.emoticon4.Click += new System.EventHandler(this.emoticon4_Click);
            // 
            // emoticon6
            // 
            this.emoticon6.BackColor = System.Drawing.Color.Transparent;
            this.emoticon6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.emoticon6.Image = global::Splendor.Properties.Resources._6;
            this.emoticon6.Location = new System.Drawing.Point(187, 605);
            this.emoticon6.Name = "emoticon6";
            this.emoticon6.Size = new System.Drawing.Size(64, 64);
            this.emoticon6.TabIndex = 18;
            this.emoticon6.TabStop = false;
            this.emoticon6.Click += new System.EventHandler(this.emoticon6_Click);
            // 
            // emoticon5
            // 
            this.emoticon5.BackColor = System.Drawing.Color.Transparent;
            this.emoticon5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.emoticon5.Image = global::Splendor.Properties.Resources._5;
            this.emoticon5.Location = new System.Drawing.Point(121, 605);
            this.emoticon5.Name = "emoticon5";
            this.emoticon5.Size = new System.Drawing.Size(64, 64);
            this.emoticon5.TabIndex = 18;
            this.emoticon5.TabStop = false;
            this.emoticon5.Click += new System.EventHandler(this.emoticon5_Click);
            // 
            // emoticon7
            // 
            this.emoticon7.BackColor = System.Drawing.Color.Transparent;
            this.emoticon7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.emoticon7.Image = global::Splendor.Properties.Resources._7;
            this.emoticon7.Location = new System.Drawing.Point(55, 671);
            this.emoticon7.Name = "emoticon7";
            this.emoticon7.Size = new System.Drawing.Size(64, 64);
            this.emoticon7.TabIndex = 19;
            this.emoticon7.TabStop = false;
            this.emoticon7.Click += new System.EventHandler(this.emoticon7_Click);
            // 
            // emoticon8
            // 
            this.emoticon8.BackColor = System.Drawing.Color.Transparent;
            this.emoticon8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.emoticon8.Image = global::Splendor.Properties.Resources._8;
            this.emoticon8.Location = new System.Drawing.Point(121, 671);
            this.emoticon8.Name = "emoticon8";
            this.emoticon8.Size = new System.Drawing.Size(64, 64);
            this.emoticon8.TabIndex = 20;
            this.emoticon8.TabStop = false;
            this.emoticon8.Click += new System.EventHandler(this.emoticon8_Click);
            // 
            // emoticon9
            // 
            this.emoticon9.BackColor = System.Drawing.Color.Transparent;
            this.emoticon9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.emoticon9.Image = global::Splendor.Properties.Resources._9;
            this.emoticon9.Location = new System.Drawing.Point(187, 671);
            this.emoticon9.Name = "emoticon9";
            this.emoticon9.Size = new System.Drawing.Size(64, 64);
            this.emoticon9.TabIndex = 21;
            this.emoticon9.TabStop = false;
            this.emoticon9.Click += new System.EventHandler(this.emoticon9_Click);
            // 
            // label4
            // 
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label4.ForeColor = System.Drawing.SystemColors.InactiveCaption;
            this.label4.Location = new System.Drawing.Point(1276, 9);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(105, 27);
            this.label4.TabIndex = 22;
            this.label4.Text = "승리(발표)";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(1374, 788);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.emoticon9);
            this.Controls.Add(this.emoticon8);
            this.Controls.Add(this.emoticon7);
            this.Controls.Add(this.emoticon5);
            this.Controls.Add(this.emoticon6);
            this.Controls.Add(this.emoticon4);
            this.Controls.Add(this.emoticon3);
            this.Controls.Add(this.emoticon2);
            this.Controls.Add(this.emoticon1);
            this.Controls.Add(this.p4pic);
            this.Controls.Add(this.p3pic);
            this.Controls.Add(this.p2pic);
            this.Controls.Add(this.p1pic);
            this.Controls.Add(this.pr4pb3);
            this.Controls.Add(this.pr3pb3);
            this.Controls.Add(this.pr2pb3);
            this.Controls.Add(this.pr1pb3);
            this.Controls.Add(this.pr4pb2);
            this.Controls.Add(this.pr4pb1);
            this.Controls.Add(this.pr3pb2);
            this.Controls.Add(this.pr3pb1);
            this.Controls.Add(this.pr2pb2);
            this.Controls.Add(this.pr2pb1);
            this.Controls.Add(this.pr1pb2);
            this.Controls.Add(this.pr1pb1);
            this.Controls.Add(this.pr4tk2);
            this.Controls.Add(this.pr3tk2);
            this.Controls.Add(this.pr4tk1);
            this.Controls.Add(this.pr2tk2);
            this.Controls.Add(this.pr3tk1);
            this.Controls.Add(this.pr2tk1);
            this.Controls.Add(this.pr1tk1);
            this.Controls.Add(this.pr1tk2);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.pr4cards);
            this.Controls.Add(this.pr3cards);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.pr2cards);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.pr1cards);
            this.Controls.Add(this.pr4pt);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.pr3pt);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.pr2pt);
            this.Controls.Add(this.pr1pt);
            this.Controls.Add(this.gd);
            this.Controls.Add(this.bk);
            this.Controls.Add(this.per_bk);
            this.Controls.Add(this.wt);
            this.Controls.Add(this.per_wt);
            this.Controls.Add(this.be);
            this.Controls.Add(this.per_be);
            this.Controls.Add(this.gn);
            this.Controls.Add(this.per_gn);
            this.Controls.Add(this.rd);
            this.Controls.Add(this.per_rd);
            this.Controls.Add(this.gold);
            this.Controls.Add(this.black);
            this.Controls.Add(this.white);
            this.Controls.Add(this.blue);
            this.Controls.Add(this.green);
            this.Controls.Add(this.red);
            this.Controls.Add(this.pic_player4);
            this.Controls.Add(this.pic_player3);
            this.Controls.Add(this.pic_player2);
            this.Controls.Add(this.pic_player1);
            this.Controls.Add(this.start);
            this.Controls.Add(this.selectTokens);
            this.Controls.Add(this.player4);
            this.Controls.Add(this.player3);
            this.Controls.Add(this.player2);
            this.Controls.Add(this.stick2);
            this.Controls.Add(this.stick);
            this.Controls.Add(this.back);
            this.Controls.Add(this.ok);
            this.Controls.Add(this.keep);
            this.Controls.Add(this.buy);
            this.Controls.Add(this.timer);
            this.Controls.Add(this.player1);
            this.Controls.Add(this.gameout);
            this.Controls.Add(this.keep0);
            this.Controls.Add(this.buy3);
            this.Controls.Add(this.buy2);
            this.Controls.Add(this.buy1);
            this.Controls.Add(this.buy0);
            this.Controls.Add(this.keep2);
            this.Controls.Add(this.keep1);
            this.Controls.Add(this.st11);
            this.Controls.Add(this.st7);
            this.Controls.Add(this.st1);
            this.Controls.Add(this.st15);
            this.Controls.Add(this.st10);
            this.Controls.Add(this.st9);
            this.Controls.Add(this.st6);
            this.Controls.Add(this.st5);
            this.Controls.Add(this.st2);
            this.Controls.Add(this.st8);
            this.Controls.Add(this.st3);
            this.Controls.Add(this.st4);
            this.Controls.Add(this.st14);
            this.Controls.Add(this.st0);
            this.Controls.Add(this.st13);
            this.Controls.Add(this.st12);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.listBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Main";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Home";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Main_FormClosing);
            this.Load += new System.EventHandler(this.Main_Load);
            this.Paint += new System.Windows.Forms.PaintEventHandler(this.Main_Paint);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Main_MouseDown);
            ((System.ComponentModel.ISupportInitialize)(this.st12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.st13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.st14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.st15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.st0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.st3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.st2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.st1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.st4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.st5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.st6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.st7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.st8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.st9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.st10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.st11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.keep1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.keep0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.keep2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.buy0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.buy1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.buy2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.buy3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_player1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_player2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_player3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_player4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pr1pb1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pr1pb2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pr1pb3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pr2pb1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pr2pb2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pr2pb3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pr3pb1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pr3pb2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pr3pb3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pr4pb1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pr4pb2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pr4pb3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.p1pic)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.p2pic)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.p3pic)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.p4pic)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emoticon1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emoticon2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emoticon3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emoticon4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emoticon6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emoticon5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emoticon7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emoticon8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emoticon9)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label gameout;
        private System.Windows.Forms.PictureBox pic_player1;
        private System.Windows.Forms.Label player1;
        private System.Windows.Forms.Label player2;
        private System.Windows.Forms.PictureBox pic_player2;
        private System.Windows.Forms.Label player3;
        private System.Windows.Forms.PictureBox pic_player3;
        private System.Windows.Forms.Label player4;
        private System.Windows.Forms.PictureBox pic_player4;
        private System.Windows.Forms.Label start;
        private System.Windows.Forms.Label buy;
        private System.Windows.Forms.Label keep;
        private System.Windows.Forms.Label stick;
        private System.Windows.Forms.Label ok;
        private System.Windows.Forms.Label back;
        private System.Windows.Forms.Label stick2;
        private System.Windows.Forms.Label selectTokens;
        public System.Windows.Forms.PictureBox st12;
        public System.Windows.Forms.PictureBox st13;
        public System.Windows.Forms.PictureBox st14;
        public System.Windows.Forms.PictureBox st15;
        public System.Windows.Forms.PictureBox st0;
        public System.Windows.Forms.PictureBox st3;
        public System.Windows.Forms.PictureBox st2;
        public System.Windows.Forms.PictureBox st1;
        public System.Windows.Forms.PictureBox st4;
        public System.Windows.Forms.PictureBox st5;
        public System.Windows.Forms.PictureBox st6;
        public System.Windows.Forms.PictureBox st7;
        public System.Windows.Forms.PictureBox st8;
        public System.Windows.Forms.PictureBox st9;
        public System.Windows.Forms.PictureBox st10;
        public System.Windows.Forms.PictureBox st11;
        public System.Windows.Forms.PictureBox keep1;
        public System.Windows.Forms.PictureBox keep0;
        public System.Windows.Forms.PictureBox keep2;
        public System.Windows.Forms.PictureBox buy0;
        public System.Windows.Forms.PictureBox buy1;
        public System.Windows.Forms.PictureBox buy2;
        public System.Windows.Forms.PictureBox buy3;
        private System.Windows.Forms.Label red;
        private System.Windows.Forms.Label green;
        private System.Windows.Forms.Label blue;
        private System.Windows.Forms.Label white;
        private System.Windows.Forms.Label black;
        private System.Windows.Forms.Label gold;
        private System.Windows.Forms.Label per_rd;
        private System.Windows.Forms.Label rd;
        private System.Windows.Forms.Label per_gn;
        private System.Windows.Forms.Label gn;
        private System.Windows.Forms.Label per_be;
        private System.Windows.Forms.Label be;
        private System.Windows.Forms.Label per_wt;
        private System.Windows.Forms.Label wt;
        private System.Windows.Forms.Label per_bk;
        private System.Windows.Forms.Label bk;
        private System.Windows.Forms.Label gd;
        private System.Windows.Forms.Label pr1pt;
        private System.Windows.Forms.Label pr1tk2;
        private System.Windows.Forms.Label pr2tk1;
        private System.Windows.Forms.Label pr2tk2;
        private System.Windows.Forms.Label pr3tk1;
        private System.Windows.Forms.Label pr3tk2;
        private System.Windows.Forms.Label pr4tk1;
        private System.Windows.Forms.Label pr4tk2;
        private System.Windows.Forms.PictureBox pr1pb1;
        private System.Windows.Forms.PictureBox pr1pb2;
        private System.Windows.Forms.PictureBox pr1pb3;
        private System.Windows.Forms.PictureBox pr2pb1;
        private System.Windows.Forms.PictureBox pr2pb2;
        private System.Windows.Forms.PictureBox pr2pb3;
        private System.Windows.Forms.PictureBox pr3pb1;
        private System.Windows.Forms.PictureBox pr3pb2;
        private System.Windows.Forms.PictureBox pr3pb3;
        private System.Windows.Forms.PictureBox pr4pb1;
        private System.Windows.Forms.PictureBox pr4pb2;
        private System.Windows.Forms.PictureBox pr4pb3;
        private System.Windows.Forms.Label pr1tk1;
        private System.Windows.Forms.Label pr1cards;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label pr2pt;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label pr2cards;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label pr3pt;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label pr3cards;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label pr4pt;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label pr4cards;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label timer;
        private System.Windows.Forms.PictureBox p1pic;
        private System.Windows.Forms.PictureBox p2pic;
        private System.Windows.Forms.PictureBox p3pic;
        private System.Windows.Forms.PictureBox p4pic;
        private System.Windows.Forms.PictureBox emoticon1;
        private System.Windows.Forms.PictureBox emoticon2;
        private System.Windows.Forms.PictureBox emoticon3;
        private System.Windows.Forms.PictureBox emoticon4;
        private System.Windows.Forms.PictureBox emoticon6;
        private System.Windows.Forms.PictureBox emoticon5;
        private System.Windows.Forms.PictureBox emoticon7;
        private System.Windows.Forms.PictureBox emoticon8;
        private System.Windows.Forms.PictureBox emoticon9;
        private System.Windows.Forms.Label label4;
    }
}